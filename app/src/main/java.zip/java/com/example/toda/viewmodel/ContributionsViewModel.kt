package com.example.toda.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.toda.data.FirebaseContribution
import com.google.firebase.database.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ContributionsViewModel : ViewModel() {
    private val database = FirebaseDatabase.getInstance()
    private val contributionsRef = database.getReference("contributions")

    private val _contributions = MutableStateFlow<List<FirebaseContribution>>(emptyList())
    private val _searchQuery = MutableStateFlow("")
    private val _selectedDate = MutableStateFlow<Date?>(null)

    val searchQuery = _searchQuery.asStateFlow()
    val selectedDate = _selectedDate.asStateFlow()

    private val _todayTotal = MutableStateFlow(0.0)
    val todayTotal = _todayTotal.asStateFlow()

    private val _monthTotal = MutableStateFlow(0.0)
    val monthTotal = _monthTotal.asStateFlow()

    // Filtered contributions
    val filteredContributions = combine(
        _contributions,
        _searchQuery,
        _selectedDate
    ) { contributions, query, date ->
        var result = contributions

        // Apply search query filter
        if (query.isNotEmpty()) {
            result = result.filter { contribution ->
                contribution.driverName.contains(query, ignoreCase = true) ||
                contribution.driverId.contains(query, ignoreCase = true)
            }
        }

        // Apply date filter
        if (date != null) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val dateStr = sdf.format(date)
            result = result.filter {
                val contributionDate = sdf.format(Date(it.timestamp * 1000))
                contributionDate == dateStr
            }
        }

        result.sortedByDescending { it.timestamp }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    init {
        contributionsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                viewModelScope.launch {
                    val contributionsList = mutableListOf<FirebaseContribution>()
                    for (contributionSnapshot in snapshot.children) {
                        try {
                            val timestamp = contributionSnapshot.child("timestamp").getValue(String::class.java) ?: ""
                            val amount = contributionSnapshot.child("amount").getValue(Long::class.java)?.toDouble() ?: 0.0
                            val driverName = contributionSnapshot.child("driverName").getValue(String::class.java) ?: ""
                            val driverRFID = contributionSnapshot.child("driverRFID").getValue(String::class.java) ?: ""

                            val contribution = FirebaseContribution(
                                driverId = driverRFID,
                                driverName = driverName,
                                amount = amount,
                                timestamp = timestamp.toLongOrNull() ?: 0L,
                                source = "hardware"
                            )
                            contributionsList.add(contribution)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    _contributions.value = contributionsList
                    updateTotals(contributionsList)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                error.toException().printStackTrace()
            }
        })
    }

    private fun updateTotals(contributions: List<FirebaseContribution>) {
        val calendar = Calendar.getInstance()

        // Get start of today
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfDay = calendar.timeInMillis / 1000 // Convert to seconds to match Firebase timestamps

        // Get start of month
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val startOfMonth = calendar.timeInMillis / 1000

        val todayTotal = contributions
            .filter { it.timestamp >= startOfDay }
            .sumOf { it.amount }

        val monthTotal = contributions
            .filter { it.timestamp >= startOfMonth }
            .sumOf { it.amount }

        _todayTotal.value = todayTotal
        _monthTotal.value = monthTotal
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateDateFilter(date: Date?) {
        _selectedDate.value = date
    }

    fun clearFilters() {
        _searchQuery.value = ""
        _selectedDate.value = null
    }

    fun getFormattedAmount(amount: Double): String {
        return "₱%.2f".format(Locale.US, amount)
    }
}
