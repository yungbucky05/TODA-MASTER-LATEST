package com.example.toda.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.toda.data.FirebaseUser
import com.example.toda.viewmodel.AdminLoginViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminLoginScreen(
    onLoginSuccess: (String, FirebaseUser) -> Unit,
    onBack: () -> Unit,
    viewModel: AdminLoginViewModel = hiltViewModel()
) {
    var phoneNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isRegistrationMode by remember { mutableStateOf(false) }

    // Registration fields
    var name by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var employeeId by remember { mutableStateOf("") }
    var position by remember { mutableStateOf("") }
    var authorizationCode by remember { mutableStateOf("") }

    val loginState by viewModel.loginState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    // Handle successful login
    LaunchedEffect(loginState.isSuccess, currentUser) {
        if (loginState.isSuccess && loginState.userId != null && currentUser != null) {
            onLoginSuccess(loginState.userId!!, currentUser!!)
        }
    }

    // Clear errors when user starts typing
    LaunchedEffect(phoneNumber, password) {
        if (loginState.error != null) {
            viewModel.clearError()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = if (isRegistrationMode) "Admin Registration" else "Admin Login",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        // Mode Toggle
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = { isRegistrationMode = false },
                    modifier = Modifier.weight(1f),
                    colors = if (!isRegistrationMode) ButtonDefaults.buttonColors()
                           else ButtonDefaults.outlinedButtonColors()
                ) {
                    Text("Sign In")
                }
                Button(
                    onClick = { isRegistrationMode = true },
                    modifier = Modifier.weight(1f),
                    colors = if (isRegistrationMode) ButtonDefaults.buttonColors()
                           else ButtonDefaults.outlinedButtonColors()
                ) {
                    Text("Register")
                }
            }
        }

        // Welcome Message
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRegistrationMode) "Join TODA Administration!" else "Welcome, Administrator!",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isRegistrationMode)
                          "Register as a TODA administrator to manage operations in Barangay 177."
                          else "Access administrative functions and manage TODA operations.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        // Login/Registration Form
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isRegistrationMode) "Administrator Registration Form" else "Administrator Login",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // Error message
                if (loginState.error != null) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Error,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = loginState.error!!,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                // Registration-only fields
                if (isRegistrationMode) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name") },
                        leadingIcon = {
                            Icon(Icons.Default.Person, contentDescription = null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading
                    )

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Address") },
                        leadingIcon = {
                            Icon(Icons.Default.LocationOn, contentDescription = null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading,
                        supportingText = {
                            Text(
                                text = "Official address for TODA records",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    )

                    OutlinedTextField(
                        value = employeeId,
                        onValueChange = { employeeId = it },
                        label = { Text("Employee/Officer ID") },
                        leadingIcon = {
                            Icon(Icons.Default.Badge, contentDescription = null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading,
                        supportingText = {
                            Text(
                                text = "Official TODA officer identification number",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    )

                    OutlinedTextField(
                        value = position,
                        onValueChange = { position = it },
                        label = { Text("Position/Role") },
                        leadingIcon = {
                            Icon(Icons.Default.Work, contentDescription = null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading,
                        supportingText = {
                            Text(
                                text = "Your role in TODA administration (e.g., President, Secretary, etc.)",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    )

                    OutlinedTextField(
                        value = authorizationCode,
                        onValueChange = { authorizationCode = it },
                        label = { Text("Authorization Code") },
                        leadingIcon = {
                            Icon(Icons.Default.Security, contentDescription = null)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading,
                        visualTransformation = PasswordVisualTransformation(),
                        supportingText = {
                            Text(
                                text = "Special authorization code provided by TODA leadership",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    )
                }

                // Phone Number Field
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = {
                        val cleaned = it.filter { char -> char.isDigit() || char == '+' }
                        if (cleaned.length <= 13) phoneNumber = cleaned
                    },
                    label = { Text("Phone Number") },
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    placeholder = { Text("09XXXXXXXXX or +639XXXXXXXXX") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !loginState.isLoading,
                    supportingText = {
                        Text(
                            text = if (isRegistrationMode) "This will be your admin login phone number"
                                  else "Enter your registered admin phone number",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )

                // Password Field
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null)
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Default.VisibilityOff
                                else Icons.Default.Visibility,
                                contentDescription = if (passwordVisible) "Hide password" else "Show password"
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None
                                         else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !loginState.isLoading
                )

                // Confirm Password Field (registration only)
                if (isRegistrationMode) {
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it },
                        label = { Text("Confirm Password") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null)
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading,
                        isError = confirmPassword.isNotEmpty() && password != confirmPassword,
                        supportingText = {
                            if (confirmPassword.isNotEmpty() && password != confirmPassword) {
                                Text(
                                    text = "Passwords do not match",
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    )
                }

                // Login/Register Button
                Button(
                    onClick = {
                        if (isRegistrationMode) {
                            viewModel.registerAdmin(
                                name = name,
                                phoneNumber = phoneNumber,
                                password = password,
                                position = position,
                                employeeId = employeeId,
                                authorizationCode = authorizationCode
                            )
                        } else {
                            viewModel.login(phoneNumber, password)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !loginState.isLoading &&
                             phoneNumber.isNotBlank() &&
                             password.isNotBlank() &&
                             (!isRegistrationMode || (name.isNotBlank() &&
                                                     address.isNotBlank() &&
                                                     employeeId.isNotBlank() &&
                                                     position.isNotBlank() &&
                                                     authorizationCode.isNotBlank() &&
                                                     password == confirmPassword))
                ) {
                    if (loginState.isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        if (loginState.isLoading) {
                            if (isRegistrationMode) "Processing Application..." else "Signing In..."
                        } else {
                            if (isRegistrationMode) "Submit Application" else "Sign In"
                        }
                    )
                }

                if (isRegistrationMode) {
                    // Registration requirements
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "📋 Administrator Registration Requirements",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "• Must be an elected or appointed TODA officer\n" +
                                      "• Valid authorization from TODA leadership\n" +
                                      "• Official employee/officer identification\n" +
                                      "• Responsibility for system administration\n" +
                                      "• Application requires approval from existing admins",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Security Information
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "🔐 Administrator Access",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "• Full system management\n• Driver application approval\n• Financial reports access\n• User management\n• System configuration",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
