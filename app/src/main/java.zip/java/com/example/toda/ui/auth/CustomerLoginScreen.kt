package com.example.toda.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.toda.viewmodel.CustomerLoginViewModel
import com.example.toda.data.FirebaseUser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerLoginScreen(
    onLoginSuccess: (String, FirebaseUser) -> Unit,
    onRegisterClick: () -> Unit,
    viewModel: CustomerLoginViewModel = hiltViewModel()
) {
    var phoneNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isRegistrationMode by remember { mutableStateOf(false) }
    var currentRegistrationStep by remember { mutableStateOf(1) }
    val maxRegistrationSteps = 4

    // Basic Information (Step 1)
    var name by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    // Personal Details (Step 2)
    var address by remember { mutableStateOf("") }
    var dateOfBirth by remember { mutableStateOf<Long?>(null) }
    var gender by remember { mutableStateOf("") }
    var occupation by remember { mutableStateOf("") }

    // Emergency Contact (Step 3)
    var emergencyContactName by remember { mutableStateOf("") }
    var emergencyContact by remember { mutableStateOf("") }

    // Preferences & Terms (Step 4)
    var smsNotifications by remember { mutableStateOf(true) }
    var bookingUpdates by remember { mutableStateOf(true) }
    var promotionalMessages by remember { mutableStateOf(false) }
    var emergencyAlerts by remember { mutableStateOf(true) }
    var agreesToTerms by remember { mutableStateOf(false) }

    val loginState by viewModel.loginState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    // Handle successful login
    LaunchedEffect(loginState.isSuccess, currentUser) {
        if (loginState.isSuccess && loginState.userId != null && currentUser != null) {
            onLoginSuccess(loginState.userId!!, currentUser!!)
        }
    }

    // Clear errors when user starts typing
    LaunchedEffect(phoneNumber, password) {
        if (loginState.error != null) {
            viewModel.clearError()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App Logo/Title
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.DirectionsCar,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "TODA Booking",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Passenger Portal - Barangay 177, Caloocan City",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Mode Toggle
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        isRegistrationMode = false
                        currentRegistrationStep = 1 // Reset to first step
                    },
                    modifier = Modifier.weight(1f),
                    colors = if (!isRegistrationMode) ButtonDefaults.buttonColors()
                           else ButtonDefaults.outlinedButtonColors()
                ) {
                    Text("Sign In")
                }
                Button(
                    onClick = { isRegistrationMode = true },
                    modifier = Modifier.weight(1f),
                    colors = if (isRegistrationMode) ButtonDefaults.buttonColors()
                           else ButtonDefaults.outlinedButtonColors()
                ) {
                    Text("Register")
                }
            }
        }

        // Registration Progress Indicator (only show in registration mode)
        if (isRegistrationMode) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Registration Progress",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Step $currentRegistrationStep of $maxRegistrationSteps",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { currentRegistrationStep.toFloat() / maxRegistrationSteps },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Login/Registration Form
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isRegistrationMode) {
                        when (currentRegistrationStep) {
                            1 -> "Basic Information"
                            2 -> "Personal Details"
                            3 -> "Emergency Contact"
                            4 -> "Preferences & Terms"
                            else -> "Passenger Registration"
                        }
                    } else "Passenger Login",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                // Error message
                if (loginState.error != null) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Error,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = loginState.error!!,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                // Content based on mode and step
                if (isRegistrationMode) {
                    when (currentRegistrationStep) {
                        1 -> {
                            // Basic Information Step
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text("Full Name") },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading
                            )

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = {
                                    val cleaned = it.filter { char -> char.isDigit() || char == '+' }
                                    if (cleaned.length <= 13) phoneNumber = cleaned
                                },
                                label = { Text("Phone Number") },
                                leadingIcon = {
                                    Icon(Icons.Default.Phone, contentDescription = null)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                placeholder = { Text("09XXXXXXXXX") },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading
                            )

                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Password") },
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null)
                                },
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            if (passwordVisible) Icons.Default.VisibilityOff
                                            else Icons.Default.Visibility,
                                            contentDescription = if (passwordVisible) "Hide password" else "Show password"
                                        )
                                    }
                                },
                                visualTransformation = if (passwordVisible) VisualTransformation.None
                                                     else PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading
                            )

                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it },
                                label = { Text("Confirm Password") },
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null)
                                },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading,
                                isError = confirmPassword.isNotEmpty() && password != confirmPassword,
                                supportingText = {
                                    if (confirmPassword.isNotEmpty() && password != confirmPassword) {
                                        Text(
                                            text = "Passwords do not match",
                                            color = MaterialTheme.colorScheme.error,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            )
                        }
                        2 -> {
                            // Personal Details Step
                            OutlinedTextField(
                                value = address,
                                onValueChange = { address = it },
                                label = { Text("Address") },
                                leadingIcon = {
                                    Icon(Icons.Default.LocationOn, contentDescription = null)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading,
                                supportingText = {
                                    Text(
                                        text = "Address within Barangay 177, Caloocan City",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            )

                            // Date of Birth Picker would go here - simplified for now
                            OutlinedTextField(
                                value = "", // You'd implement date picker logic
                                onValueChange = { },
                                label = { Text("Date of Birth") },
                                leadingIcon = {
                                    Icon(Icons.Default.CalendarToday, contentDescription = null)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading,
                                placeholder = { Text("Select date of birth") }
                            )

                            // Gender Selection
                            var expandedGender by remember { mutableStateOf(false) }
                            val genderOptions = listOf("Male", "Female", "Other", "Prefer not to say")

                            ExposedDropdownMenuBox(
                                expanded = expandedGender,
                                onExpandedChange = { expandedGender = !expandedGender }
                            ) {
                                OutlinedTextField(
                                    value = gender,
                                    onValueChange = { },
                                    readOnly = true,
                                    label = { Text("Gender") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Person, contentDescription = null)
                                    },
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedGender)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor(),
                                    enabled = !loginState.isLoading
                                )
                                ExposedDropdownMenu(
                                    expanded = expandedGender,
                                    onDismissRequest = { expandedGender = false }
                                ) {
                                    genderOptions.forEach { option ->
                                        DropdownMenuItem(
                                            text = { Text(option) },
                                            onClick = {
                                                gender = option
                                                expandedGender = false
                                            }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = occupation,
                                onValueChange = { occupation = it },
                                label = { Text("Occupation") },
                                leadingIcon = {
                                    Icon(Icons.Default.Work, contentDescription = null)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading
                            )
                        }
                        3 -> {
                            // Emergency Contact Step
                            Text(
                                text = "Emergency Contact Information",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Please provide emergency contact details for safety purposes.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            OutlinedTextField(
                                value = emergencyContactName,
                                onValueChange = { emergencyContactName = it },
                                label = { Text("Emergency Contact Name") },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading
                            )

                            OutlinedTextField(
                                value = emergencyContact,
                                onValueChange = {
                                    val cleaned = it.filter { char -> char.isDigit() || char == '+' }
                                    if (cleaned.length <= 13) emergencyContact = cleaned
                                },
                                label = { Text("Emergency Contact Phone") },
                                leadingIcon = {
                                    Icon(Icons.Default.Phone, contentDescription = null)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                placeholder = { Text("09XXXXXXXXX") },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !loginState.isLoading
                            )
                        }
                        4 -> {
                            // Preferences & Terms Step
                            Text(
                                text = "Notification Preferences",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = smsNotifications,
                                    onCheckedChange = { smsNotifications = it }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("SMS Notifications")
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = bookingUpdates,
                                    onCheckedChange = { bookingUpdates = it }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Booking Updates")
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = promotionalMessages,
                                    onCheckedChange = { promotionalMessages = it }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Promotional Messages")
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = emergencyAlerts,
                                    onCheckedChange = { emergencyAlerts = it }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Emergency Alerts")
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = agreesToTerms,
                                            onCheckedChange = { agreesToTerms = it }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "I agree to the Terms and Conditions and Privacy Policy",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Navigation buttons for registration
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        if (currentRegistrationStep > 1) {
                            OutlinedButton(
                                onClick = { currentRegistrationStep-- },
                                enabled = !loginState.isLoading
                            ) {
                                Text("Previous")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(1.dp)) // Placeholder
                        }

                        if (currentRegistrationStep < maxRegistrationSteps) {
                            Button(
                                onClick = {
                                    // Validate current step before proceeding
                                    val canProceed = when (currentRegistrationStep) {
                                        1 -> name.isNotBlank() && phoneNumber.isNotBlank() &&
                                             password.isNotBlank() && password == confirmPassword
                                        2 -> address.isNotBlank() && gender.isNotBlank() && occupation.isNotBlank()
                                        3 -> emergencyContactName.isNotBlank() && emergencyContact.isNotBlank()
                                        else -> true
                                    }
                                    if (canProceed) {
                                        currentRegistrationStep++
                                    }
                                },
                                enabled = !loginState.isLoading
                            ) {
                                Text("Next")
                            }
                        } else {
                            Button(
                                onClick = {
                                    // Handle final registration submission
                                    // You'll need to implement this with proper registration logic
                                },
                                enabled = !loginState.isLoading && agreesToTerms
                            ) {
                                if (loginState.isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text(if (loginState.isLoading) "Creating Account..." else "Complete Registration")
                            }
                        }
                    }
                } else {
                    // Login Mode - Simplified single step
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = {
                            val cleaned = it.filter { char -> char.isDigit() || char == '+' }
                            if (cleaned.length <= 13) phoneNumber = cleaned
                        },
                        label = { Text("Phone Number") },
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        placeholder = { Text("09XXXXXXXXX or +639XXXXXXXXX") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading,
                        supportingText = {
                            Text(
                                text = "Enter your registered phone number",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff
                                    else Icons.Default.Visibility,
                                    contentDescription = if (passwordVisible) "Hide password" else "Show password"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None
                                             else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading
                    )

                    Button(
                        onClick = {
                            viewModel.login(phoneNumber, password)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loginState.isLoading && phoneNumber.isNotBlank() && password.isNotBlank()
                    ) {
                        if (loginState.isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(if (loginState.isLoading) "Signing In..." else "Sign In")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // App Information
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "📍 Service Area",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "We serve within Barangay 177, Caloocan City",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "🕒 Operating Hours",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Monday to Sunday, 6:00 AM - 10:00 PM",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
