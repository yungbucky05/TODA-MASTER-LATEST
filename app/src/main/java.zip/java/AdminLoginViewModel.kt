package com.example.toda.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.toda.data.FirebaseUser
import com.example.toda.data.LoginState
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

@HiltViewModel
class AdminLoginViewModel @Inject constructor(
    private val auth: FirebaseAuth,
    private val database: FirebaseDatabase
) : ViewModel() {

    private val _loginState = MutableStateFlow(LoginState())
    val loginState: StateFlow<LoginState> = _loginState.asStateFlow()

    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    fun login(phoneNumber: String, password: String) {
        viewModelScope.launch {
            try {
                _loginState.value = _loginState.value.copy(isLoading = true, error = null)

                // Create email from phone number for Firebase Auth
                val email = "${phoneNumber}@toda-admin.com"

                val result = auth.signInWithEmailAndPassword(email, password).await()
                val user = result.user

                if (user != null) {
                    // Fetch admin profile from database
                    val userRef = database.getReference("users/${user.uid}")
                    val snapshot = userRef.get().await()

                    if (snapshot.exists()) {
                        @Suppress("UNCHECKED_CAST")
                        val userData = snapshot.getValue(Map::class.java) as? Map<String, Any>
                        val userType = userData?.get("userType") as? String

                        if (userType == "ADMIN") {
                            val firebaseUser = FirebaseUser(
                                id = user.uid,
                                name = userData["name"] as? String ?: "",
                                phoneNumber = userData["phoneNumber"] as? String ?: phoneNumber,
                                userType = "ADMIN",
                                isVerified = userData["isVerified"] as? Boolean ?: false,
                                isActive = userData["isActive"] as? Boolean ?: true
                            )

                            _currentUser.value = firebaseUser
                            _loginState.value = _loginState.value.copy(
                                isLoading = false,
                                isSuccess = true,
                                userId = user.uid
                            )
                        } else {
                            _loginState.value = _loginState.value.copy(
                                isLoading = false,
                                error = "Access denied. Admin privileges required."
                            )
                        }
                    } else {
                        _loginState.value = _loginState.value.copy(
                            isLoading = false,
                            error = "Admin account not found."
                        )
                    }
                }
            } catch (e: Exception) {
                _loginState.value = _loginState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Login failed"
                )
            }
        }
    }

    fun registerAdmin(
        name: String,
        phoneNumber: String,
        password: String,
        position: String,
        employeeId: String,
        authorizationCode: String
    ) {
        viewModelScope.launch {
            try {
                _loginState.value = _loginState.value.copy(isLoading = true, error = null)

                // Verify authorization code (you can customize this validation)
                if (authorizationCode != "TODA-ADMIN-2025") {
                    _loginState.value = _loginState.value.copy(
                        isLoading = false,
                        error = "Invalid authorization code"
                    )
                    return@launch
                }

                // Create email from phone number for Firebase Auth
                val email = "${phoneNumber}@toda-admin.com"

                val result = auth.createUserWithEmailAndPassword(email, password).await()
                val user = result.user

                if (user != null) {
                    // Create admin profile in database
                    val adminData = mapOf(
                        "id" to user.uid,
                        "name" to name,
                        "phoneNumber" to phoneNumber,
                        "userType" to "ADMIN",
                        "position" to position,
                        "employeeId" to employeeId,
                        "isVerified" to true,
                        "isActive" to true,
                        "registrationDate" to System.currentTimeMillis(),
                        "lastActiveTime" to System.currentTimeMillis(),
                        "membershipStatus" to "ACTIVE"
                    )

                    val adminProfileData = mapOf(
                        "name" to name,
                        "phoneNumber" to phoneNumber,
                        "userType" to "ADMIN",
                        "position" to position,
                        "employeeId" to employeeId,
                        "address" to "TODA Office, Barangay 177, Caloocan City",
                        "emergencyContact" to phoneNumber,
                        "isBlocked" to false,
                        "isOnline" to false,
                        "rating" to 5.0,
                        "totalBookings" to 0,
                        "completedBookings" to 0,
                        "cancelledBookings" to 0,
                        "earnings" to 0.0,
                        "totalTrips" to 0,
                        "lastBookingTime" to 0L,
                        "trustScore" to 100.0,
                        "yearsOfExperience" to 0
                    )

                    // Save to both collections
                    database.getReference("users/${user.uid}").setValue(adminData).await()
                    database.getReference("userProfiles/${user.uid}").setValue(adminProfileData).await()
                    database.getReference("phoneNumberIndex/$phoneNumber").setValue(user.uid).await()

                    val firebaseUser = FirebaseUser(
                        id = user.uid,
                        name = name,
                        phoneNumber = phoneNumber,
                        userType = "ADMIN",
                        isVerified = true,
                        isActive = true
                    )

                    _currentUser.value = firebaseUser
                    _loginState.value = _loginState.value.copy(
                        isLoading = false,
                        isSuccess = true,
                        userId = user.uid
                    )
                }
            } catch (e: Exception) {
                _loginState.value = _loginState.value.copy(
                    isLoading = false,
                    error = e.message ?: "Registration failed"
                )
            }
        }
    }

    fun clearError() {
        _loginState.value = _loginState.value.copy(error = null)
    }
}
